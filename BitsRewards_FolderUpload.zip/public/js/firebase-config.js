// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-analytics.js";

const firebaseConfig = {
  apiKey: "AIzaSyCvWqj6cbJ0A86Td9nKkLP7moZInnlyTDY",
  authDomain: "bits-rewads.firebaseapp.com",
  projectId: "bits-rewads",
  storageBucket: "bits-rewads.firebasestorage.app",
  messagingSenderId: "261837019220",
  appId: "1:261837019220:web:25f3f33b6a6486cf69f5c1",
  measurementId: "G-HBEQ1TE4VN"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);