
const express = require("express");
const stripe = require("stripe")("sk_test_51RJxweG..."); // ضع secret key
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.json());

app.post("/create-checkout-session", async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    mode: "payment",
    line_items: [{
      price_data: {
        currency: "usd",
        unit_amount: 400 * 100,
        product_data: {
          name: "BitsRewards Signup",
          description: "Receive 800 Bits on signup"
        }
      },
      quantity: 1
    }],
    success_url: "https://yamen701.github.io/confirmation.html",
    cancel_url: "https://yamen701.github.io/register.html",
    metadata: {
      user_email: req.body.email,
      user_name: req.body.name
    }
  });

  res.json({ id: session.id });
});

app.listen(4242, () => console.log("Server running on http://localhost:4242"));
